package com.amdocs.kafka.springbootkafkaproducerexample.listner;

import com.amdocs.kafka.springbootkafkaproducerexample.model.User;
import com.amdocs.kafka.springbootkafkaproducerexample.repo.UserRepo;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;


@Service
public class KafkaListner {
    @Autowired
    private UserRepo userRepo;

    @Value("${topics}")
    private String topic;

    @KafkaListener(topics="Kafka_Example",group = "group_id")
    public String listen(String message)
    {
        System.out.println("================> "+message);
        return "message resived";
    }

    @KafkaListener(topics="Kafka_Test" ,group = "group_json",containerFactory = "userKafkaListenerFactory")
    public String listenObject(User message)
    {
        System.out.println("object consumed ================> "+message);
        userRepo.save(message);
        return "message resived";
    }

}
