package com.amdocs.kafka.springbootkafkaproducerexample.repo;

import com.amdocs.kafka.springbootkafkaproducerexample.model.User;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface UserRepo extends MongoRepository<User,Integer> {
}
