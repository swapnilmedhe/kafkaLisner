package com.amdocs.kafka.springbootkafkaproducerexample.resource;

import com.amdocs.kafka.springbootkafkaproducerexample.model.User;
import com.amdocs.kafka.springbootkafkaproducerexample.repo.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("kafka")
public class UserResource {

    @Autowired
    private KafkaTemplate<String, User> kafkaTemplate;

    @Autowired
    private UserRepo userRepo;

    private static final String TOPIC = "Kafka_Test";

    @GetMapping("/publish/{name}")
    public String post(@PathVariable("name") final String name) {

        kafkaTemplate.send(TOPIC, new User(name, "Technology", 12000L));

        return "Published successfully";
    }

    @PostMapping("/publish")
    public String postObj(@RequestBody User user) {

        kafkaTemplate.send(TOPIC, user);

        return "Published successfully";
    }

    @GetMapping("/")
    public List<User> get() {
        return userRepo.findAll();
    }
}
