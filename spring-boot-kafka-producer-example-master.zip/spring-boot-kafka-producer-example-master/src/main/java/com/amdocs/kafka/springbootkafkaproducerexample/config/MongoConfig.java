package com.amdocs.kafka.springbootkafkaproducerexample.config;

import com.amdocs.kafka.springbootkafkaproducerexample.repo.UserRepo;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@Configuration
@EnableMongoRepositories(basePackageClasses = UserRepo.class)
public class MongoConfig {}
